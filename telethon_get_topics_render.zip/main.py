from telethon import TelegramClient
from telethon.tl.functions.messages import GetForumTopicsRequest

api_id = 22816347
api_hash = "2517db51e07a3fd484b0c938490aa27b"
session_name = "session"

client = TelegramClient(session_name, api_id, api_hash)

async def main():
    await client.start()
    chat_id = -1002256623070  # Remplace par l’ID de ton supergroupe forum

    try:
        result = await client(GetForumTopicsRequest(peer=chat_id, offset_date=None, offset_id=0, offset_topic=0, limit=100))
        print("📚 Topics trouvés :")
        for topic in result.topics:
            print(f"- ID: {topic.id}, Title: {topic.title}")
    except Exception as e:
        print("❌ Erreur :", e)

with client:
    client.loop.run_until_complete(main())